#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:18:04 2021

@author: valentin Merault
"""

from tkinter import Tk, PhotoImage
from datas import * 
from ihm import menu


""" Import de pygame pour les musiques : """
import pygame

pygame.mixer.init()
p = pygame.mixer.Sound('audio/pion.wav')
app = pygame.mixer.Sound('audio/applaud.wav')
pygame.mixer.music.load('audio/Jaunter-Reset.ogg')
pygame.mixer.music.set_volume(0.0)
pygame.mixer.music.play(-1)

"""Variables GLOBALE : """

n = 12

""" Creation de la fenêtre : """

fen = Tk()

fen.title("Jeu de Dame")
fen.iconbitmap('images/dame.ico')
fen.geometry("730x650")
fen.resizable(False, False)  # Dimension de la fenêtre fixe.
fen.configure(bg="#E9D7A6")


""" Initialisation des images des pions/cases : """

pionNoir = PhotoImage(file="images/pionNoir.png")
pionBlanc = PhotoImage(file="images/pionBlanc.png")
pionDame = PhotoImage(file="images/pionDB.png")
pionDame2 = PhotoImage(file="images/pionDN.png")
caseB = PhotoImage(file="images/caseB.png")
caseN = PhotoImage(file="images/caseN.png")
jeudameMenu = PhotoImage(file="images/jeudameMenu.png")


"""Creation du plateau et lancement du Menu : """

M = creation_plateau(n)
menu(M, n, fen, pionNoir, pionBlanc, caseB, caseN, p, app, jeudameMenu, pionDame, pionDame2)

fen.mainloop()
fen.protocol("WM_DELETE_WINDOW", on_closing(fen))
